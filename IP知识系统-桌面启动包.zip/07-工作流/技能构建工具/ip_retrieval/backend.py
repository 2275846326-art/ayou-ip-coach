"""One authenticated loopback worker, shared by both local stdio MCP adapters."""
from pathlib import Path
import json,os,sys,secrets,hmac,threading,hashlib,socket
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from core import Library,ToolGateway,RUNTIME,VAULT,savej

def credentials():
 RUNTIME.mkdir(parents=True,exist_ok=True);p=RUNTIME/'token'
 try:
  with p.open('x',encoding='ascii') as f:f.write(secrets.token_hex(32))
 except FileExistsError:pass
 return p.read_text(encoding='ascii').strip()

HERE=Path(__file__).resolve().parent
REVISION=hashlib.sha256(b''.join((HERE/n).read_bytes() for n in ['core.py','backend.py','mcp_server.py','local_settings.py'])).hexdigest()[:16]
PORT=0  # Let Windows select an available non-reserved loopback port.
TOKEN=credentials()
def run():
 global PORT
 lib=Library();gateway=ToolGateway(lib);serial=threading.RLock()
 class Handler(BaseHTTPRequestHandler):
  def log_message(self,*a):pass
  def do_POST(self):
   if self.path!='/rpc' or not hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+TOKEN) or self.headers.get('Origin'):
    self.send_error(403);return
   try:
    n=int(self.headers.get('Content-Length','0'))
    if not 0<n<100_000:raise ValueError('request size')
    req=json.loads(self.rfile.read(n));method=req['method'];params=req.get('params',{})
    if method not in {'status','search','read','rules'}:raise ValueError('unknown method')
    with serial:result=gateway.call(method,params,req.get('session',''))
    if method=='status':result.update(service_pid=os.getpid(),service_port=PORT,engine_revision=REVISION)
    out={'ok':True,'result':result}
   except Exception as e:out={'ok':False,'error':type(e).__name__+': '+str(e)[:400]}
   b=json.dumps(out,ensure_ascii=False).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
 class ExclusiveServer(ThreadingHTTPServer):
  allow_reuse_address=False
  def server_bind(self):
   if os.name=='nt':self.socket.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
   super().server_bind()
 server=ExclusiveServer(('127.0.0.1',0),Handler);PORT=server.server_address[1]
 savej(RUNTIME/('endpoint-'+REVISION+'.json'),{'port':PORT,'root':str(VAULT),'revision':REVISION,'pid':os.getpid()})
 # A unique diagnostic file is not a shared lock or a prerequisite for RPC.
 savej(RUNTIME/('service-'+str(os.getpid())+'.json'),{'pid':os.getpid(),'port':PORT,'root':str(VAULT),'transport':'stdio adapters / authenticated loopback backend'})
 server.serve_forever()
if __name__=='__main__':run()
