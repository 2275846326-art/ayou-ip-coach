"""Per-install paths and ownership; never distribute .local or .runtime."""
import json,re
from pathlib import Path

def settings_path(vault):
 return Path(vault)/'07-工作流/技能构建工具/ip_retrieval/.local/installation.json'

def relative_path(root,rel):
 if not isinstance(rel,str) or not rel or '\\' in rel or Path(rel).is_absolute():raise ValueError('需要库内相对路径')
 p=(Path(root)/rel).resolve()
 if not p.is_relative_to(Path(root).resolve()) or p==Path(root).resolve():raise ValueError('路径越界')
 cur=Path(root)/rel
 while cur!=Path(root):
  if cur.is_symlink() or (hasattr(cur,'is_junction') and cur.is_junction()):raise ValueError('路径含重解析点')
  cur=cur.parent
 return p

def load_settings(vault):
 p=settings_path(vault)
 s=json.loads(p.read_text(encoding='utf-8-sig')) if p.exists() else {'schema':1,'profiles':{},'models':{},'workflow_scope_policy':'catalog_required'}
 if s.get('schema')!=1 or not isinstance(s.get('profiles'),dict):raise ValueError('本机配置版本或档案映射错误')
 assigned=[]
 for ip,pf in s['profiles'].items():
  if not re.fullmatch(r'[a-z0-9][a-z0-9_-]{0,47}',ip) or ip=='shared':raise ValueError('IP-ID格式错误')
  for rel in pf.get('roots',[]):
   path=relative_path(vault,rel)
   # Only private data may be registered. Shared rules cannot be claimed by a profile.
   if not rel.startswith('02-私核-永不外传/') and rel!='02-私核-永不外传' and rel not in {'07-工作流/技能库/ayou-content-system','07-工作流/技能库/ayou-voice','07-工作流/技能库/ayou-cover','07-工作流/技能库/dada-voice-engine','07-工作流/技能库/wechat-publish'}:raise ValueError('档案映射必须位于私核')
   for other,prev in assigned:
    if other!=ip and (path.is_relative_to(prev) or prev.is_relative_to(path)):raise ValueError('不同IP资料根不可重叠')
   assigned.append((ip,path))
  for rel in pf.get('rules',[]):
   path=relative_path(vault,rel)
   if not any(owner==ip and path.is_relative_to(base) for owner,base in assigned):raise ValueError('个人规则不属于该IP')
 if s.get('workflow_scope_policy') not in {None,'catalog_required','legacy'}:raise ValueError('未知工作流范围策略')
 contexts=s.get('task_contexts',{})
 if not isinstance(contexts,dict):raise ValueError('task_contexts必须是按文件登记的对象')
 for rel,item in contexts.items():
  relative_path(vault,rel)
  if '任务记录' not in Path(rel).parts or Path(rel).suffix.lower() not in {'.md','.txt'}:raise ValueError('任务上下文只登记任务记录内的正文文件')
  if not isinstance(item,dict) or item.get('owner') not in set(s['profiles'])|{'shared'}:raise ValueError('任务归属必须明确')
  mapped=[ip for ip,pf in s['profiles'].items() for base in pf.get('roots',[]) if rel==base or rel.startswith(base+'/')]
  if (rel.startswith('02-私核-永不外传/') and not mapped) or any(ip!=item['owner'] for ip in mapped):raise ValueError('任务归属不得改变私核所有者')
 gate=s.get('relevance_gate')
 if gate is not None:
  import math
  if not isinstance(gate,dict) or gate.get('schema')!=1 or not isinstance(gate.get('threshold'),(int,float)) or not math.isfinite(gate['threshold']) or not 0<gate['threshold']<1 or not isinstance(gate.get('model_manifest'),dict) or not isinstance(gate.get('calibration_id'),str):raise ValueError('相关性校准配置损坏，停止检索')
 legacy=s.get('legacy_runtime')
 if legacy and (legacy.get('owner') not in s['profiles'] or not Path(legacy.get('path','')).is_absolute()):raise ValueError('旧运行库须明确归属及绝对路径')
 return s

def owner_for(settings,rel,role):
 if rel.startswith('@runtime/'):return settings['legacy_runtime']['owner']
 matches=[ip for ip,pf in settings['profiles'].items() for base in pf.get('roots',[]) if rel==base or rel.startswith(base+'/')]
 if matches:return matches[0]
 if role.startswith('personal') or rel.startswith('02-私核-永不外传/'):return '__unmapped__'
 return 'shared'
