from pathlib import Path
import argparse,hashlib,importlib.util,json,os,sys,tempfile,zipfile,shutil
from xml.etree import ElementTree as ET
from datetime import datetime,timezone
sys.dont_write_bytecode=True
VERSION='2.2.0'
CURRENT_IP='ayou'  # Generic deployment supplies the confirmed local IP-ID.
CONTENT_TASKS={'script','wechat','topic'}
CHECKS=['reader','opening','argument','value','sources','boundaries','expression']
PROFILES={
'wechat':(CHECKS,{'reader','opening','argument','value','boundaries','expression'}),
'script':(CHECKS,{'reader','opening','argument','value','boundaries','expression'}),
'topic':(['audience','premise','benefit','truthfulness','sources'],{'audience','premise','benefit','truthfulness'}),
'cover':(['brief_match','visual','specifications','permissions'],{'brief_match','visual','specifications','permissions'}),
'layout':(['content_preserved','readability','attachments','handoff'],{'content_preserved','readability','handoff'}),
'learning':(['explanation','application','boundary'],{'explanation','application','boundary'})}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,obj):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);name=None
    try:
        with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=p.parent,suffix='.tmp',delete=False) as f:
            name=Path(f.name);f.write(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
        os.replace(name,p)
    finally:
        if name and name.exists():name.unlink()
def now():return datetime.now(timezone.utc).isoformat()
def loader():
    p=Path(__file__).with_name('读取任务.py');spec=importlib.util.spec_from_file_location('read_plan',p)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def content(p):
    p=Path(p);suffix=p.suffix.lower()
    try:
        if suffix=='.docx':
            with zipfile.ZipFile(p) as z:
                root=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
                paras=[''.join(t.text or '' for t in x.findall('.//w:t',ns)).strip() for x in root.findall('.//w:p',ns)]
                paras=[x for x in paras if x];media=[x for x in z.namelist() if x.startswith('word/media/') and not x.endswith('/')]
            if not paras:raise ValueError('DOCX没有可读正文，需要视觉/OCR处理')
            return '\n'.join(f'[P{i}] {t}' for i,t in enumerate(paras,1)),{'format':'docx','coverage':'text_only','images_not_reviewed':len(media),'paragraphs':len(paras)}
        if suffix=='.pdf':
            try:from pypdf import PdfReader
            except ImportError:raise ValueError('缺pypdf，请使用既有蒸馏提取入口，不能宣称已读取PDF')
            try:
                reader=PdfReader(p);texts=[page.extract_text() or '' for page in reader.pages]
            except Exception as e:raise ValueError('PDF无法解析，请使用既有取材流程核查：'+str(p)) from e
            if not any(x.strip() for x in texts):raise ValueError('PDF没有可读文字，需要OCR')
            return '\n'.join(f'[Page {i}]\n{x}' for i,x in enumerate(texts,1)),{'format':'pdf','coverage':'text_only_visual_not_reviewed','pages':len(texts),'low_text_pages':[i for i,x in enumerate(texts,1) if len(x.strip())<25]}
        if suffix not in {'.md','.txt','.json','.html','.csv','.srt','.vtt','.yaml','.yml','.log'}:raise ValueError('仅支持文本/DOCX/PDF；图像或其他格式需先提取并核对：'+str(p))
        return p.read_text(encoding='utf-8-sig'),{'format':'text','coverage':'text'}
    except (UnicodeError,zipfile.BadZipFile,KeyError,ET.ParseError) as e:raise ValueError('来源无法解析，请保留缺口：'+str(p)) from e
def load(task,state,task_id,emit=False,extra=(),replace=False):
    state=Path(state)
    parent=state.read_bytes() if state.exists() else None
    if parent is not None and not replace:raise ValueError('已有状态，请显式reload，不覆盖')
    plan=loader().plan(task);required=[dict(i) for i in plan['required']];seen={i['path'] for i in required}
    for raw in extra:
        f=Path(raw).resolve()
        if not f.is_file():raise ValueError('补充来源不存在：'+str(f))
        if str(f) not in seen:required.append({'path':str(f),'sha256':sha(f),'role':'source'});seen.add(str(f))
    if str(state.resolve()) in {str(Path(i['path']).resolve()) for i in required}:raise ValueError('状态不能覆盖输入原件')
    bodies=[]
    for i in required:
        body,info=content(i['path']);i['coverage']=info;i['extracted_text_sha256']=hashlib.sha256(body.encode('utf-8')).hexdigest();bodies.append((i,body))
        if sha(i['path'])!=i['sha256']:raise ValueError('读取期间输入发生变化，请重读')
    started=now()
    if parent is not None:
        previous=json.loads(parent.decode('utf-8-sig'))
        if previous.get('task_id')==task_id:started=previous.get('started_at',previous.get('loaded_at',started))
    obj={'schema':3,'workflow_version':VERSION,'current_ip':CURRENT_IP,'task_id':task_id,'task':task,'voice_sources_expected':bool(plan.get('voice_sources_expected',False)),'started_at':started,'loaded_at':now(),'required':required,'inventory':plan['inventory'],'status':'loaded_by_tool','meaning':'只确认工具读取；内容任务还须当前任务上下文、真实MCP检索回执与正文取材对应；不证明理解、事实正确或效果'}
    if parent is not None:
        if not state.exists() or state.read_bytes()!=parent:raise ValueError('另一AI修改了状态，停止覆盖')
        archive=state.with_name(state.stem+'.before-reload-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f')+state.suffix)
        archive.write_bytes(parent)
    write(state,obj)
    if emit:
        for i,body in bodies:print('\n===== '+i['path']+' =====\n'+body)
    return obj
def template(state,draft,review):
    if Path(review).exists():raise ValueError('已有审稿文件，不覆盖')
    s=read(state);d=Path(draft).resolve();content(d)
    keys,mandatory=PROFILES[s['task']]
    obj={'task_id':s['task_id'],'task':s['task'],'draft':str(d),'draft_sha256':sha(d),'reviewer':'','review_kind':'self_review','rule_acknowledgements':[{'path':i['path'],'sha256':i['sha256'],'rule_quote':'','application':''} for i in s['required']],'checks':[{'id':k,'required':k in mandatory,'status':'pending','draft_quote':'','reason':'','action':'','recheck':''} for k in keys],'decisions':[],'user_acceptance':'not_recorded','effect_evidence':'not_tested','learning_status':'not_demonstrated'}
    if s['task'] in CONTENT_TASKS:
        obj['voice_review']={'current_ip':CURRENT_IP,'format':'','mode':'pending','sources':[],'draft_quote':'','limitation':'','feedback':{'mode':'pending','items':[]}}
        obj['task_context']={'path':'','sha256':'','source_quote':'','application':''}
        obj['retrieval']={'receipt':'','fallback_reason':''}
        obj['content_grounding']=[{'path':'','sha256':'','source_quote':'','draft_quote':'','support':'','conditions':'','use':'reference'}]
    write(review,obj);return obj

def receipt_root():
    return Path(__file__).resolve().parents[4]/'07-工作流/技能构建工具/ip_retrieval/.runtime/receipts'

def draft_body(text):
    # Keep author notes/source lists from satisfying a check on the spoken copy.
    marker='## 口播正文'
    if marker in text:
        tail=text.split(marker,1)[1].lstrip('\r\n')
        return tail.split('\n## ',1)[0]
    return text

def grounding_issues(s,r,body):
    issues=[]
    if s.get('schema')!=3 or s.get('workflow_version')!=VERSION:
        issues.append('旧内容工作流缺取材门槛，须reload并重审')
    loaded={str(Path(i['path']).resolve()):i for i in s['required']}
    context=r.get('task_context',{})
    if not isinstance(context,dict):context={}
    cp=Path(context.get('path','')).resolve();ci=loaded.get(str(cp));cq=context.get('source_quote','').strip()
    if not ci or ci.get('role')!='source' or not cp.is_file() or cp==Path(r.get('draft','')).resolve():
        issues.append('缺实际加载的当前任务上下文（不能用必读规则或正文自身代替）')
    elif context.get('sha256')!=ci['sha256'] or sha(cp)!=ci['sha256']:
        issues.append('当前任务上下文已变化，须reload')
    elif len(cq)<4 or cq not in content(cp)[0] or not context.get('application','').strip():
        issues.append('任务共识/当前决定未定位或未说明本次执行')
    retrieval=r.get('retrieval',{})
    if not isinstance(retrieval,dict):retrieval={}
    rid=retrieval.get('receipt','')
    import re
    if not isinstance(rid,str) or not re.fullmatch(r'[0-9a-f]{64}',rid):
        issues.append('缺真实MCP检索回执')
    else:
        try:
            rec=read(receipt_root()/(rid+'.json'))
            expected=hashlib.sha256(json.dumps(rec,sort_keys=True).encode()).hexdigest()
            if expected!=rid:raise ValueError('回执内容指纹不符')
            if rec.get('task')!=('topic' if s['task']=='topic' else 'writing') or rec.get('current_ip')!=CURRENT_IP or rec.get('include_personal') is not True:
                raise ValueError('回执任务或当前IP不匹配')
            if not rec.get('rule_receipt') or not rec.get('query_sha256') or rec.get('purpose')!='action':raise ValueError('回执缺规则/查询或不是行动用途')
            start=datetime.fromisoformat(s.get('started_at',s['loaded_at'])).timestamp()
            if not isinstance(rec.get('time'),(int,float)) or rec['time']<start:raise ValueError('回执早于本轮任务加载，不接受旧回执充数')
            if rec.get('status')!='candidates_require_support_check' and not retrieval.get('fallback_reason','').strip():
                raise ValueError('检索未就绪/未命中，须说明定向回查原件的原因与范围')
        except (ValueError,OSError,KeyError,TypeError) as e:
            issues.append('MCP检索回执未通过：'+str(e))
    evidence=r.get('content_grounding',[])
    if not isinstance(evidence,list) or not evidence:issues.append('只有规则加载，没有正文取材对应');return issues
    for e in evidence:
        if not isinstance(e,dict):issues.append('正文取材记录格式错误');continue
        p=Path(e.get('path','')).resolve();item=loaded.get(str(p));q=e.get('source_quote','').strip();dq=e.get('draft_quote','').strip()
        if not item or item.get('role')!='source' or p==cp or p==Path(r.get('draft','')).resolve():
            issues.append('内容材料未实际加载，或只用规则/任务共识/正文自身代替取材');continue
        if not p.is_file() or e.get('sha256')!=item['sha256'] or sha(p)!=item['sha256']:
            issues.append('内容材料变化或指纹错误：'+str(p));continue
        if len(q)<4 or q not in content(p)[0]:issues.append('内容材料引句无法定位：'+str(p))
        if len(dq)<4 or dq not in body:issues.append('材料未对应到实际正文原句（不能只写在作者备注）')
        if not e.get('support','').strip() or not e.get('conditions','').strip():issues.append('未说明材料支持关系与适用条件')
        if e.get('use') not in {'reference','example','experience','personal_preference','counterexample'}:issues.append('材料用途未区分')
    return issues
def voice_issues(s,r,body):
    """Check locatable personal-expression evidence, not whether prose sounds human."""
    issues=[];v=r.get('voice_review')
    if not isinstance(v,dict):return ['缺当前用户语感与纠偏记录']
    if v.get('current_ip')!=CURRENT_IP:issues.append('语感记录归属不符')
    if not v.get('format','').strip():issues.append('未区分本次表达形式')
    loaded={str(Path(i['path']).resolve()):i for i in s['required']}
    def locate(e,key='source_quote'):
        if not isinstance(e,dict):return False
        p=Path(e.get('path','')).resolve();i=loaded.get(str(p));q=e.get(key,'')
        return bool(i and p!=Path(r.get('draft','')).resolve() and p.is_file() and e.get('sha256')==i['sha256']==sha(p) and isinstance(q,str) and len(q.strip())>=4 and q in content(p)[0])
    mode=v.get('mode');sources=v.get('sources')
    if mode=='sample_based':
        if not isinstance(sources,list) or not sources:issues.append('有样本校准缺实际表达来源')
        else:
            for e in sources:
                if not locate(e) or e.get('kind') not in {'user_original','user_confirmed','personal_profile'} or not e.get('application','').strip():issues.append('语感来源/定位/采用说明不完整')
        q=v.get('draft_quote','')
        if not isinstance(q,str) or len(q.strip())<4 or q not in body:issues.append('语感未对应当前正文')
    elif mode=='no_samples':
        if s.get('voice_sources_expected'):issues.append('已有本人表达来源，不能声明无样本跳过')
        if not v.get('limitation','').strip():issues.append('无本人样本须声明未校准')
        if sources:issues.append('无样本模式不能同时冒充有样本')
    else:issues.append('语感校准状态未完成')
    feedback=v.get('feedback',{})
    if not isinstance(feedback,dict):feedback={}
    if feedback.get('mode')=='provided':
        items=feedback.get('items',[])
        if not isinstance(items,list) or not items:issues.append('收到纠偏但未分析本人修改')
        else:
            for e in items:
                if not locate(e,'user_quote'):issues.append('纠偏原话未实际加载或无法定位');continue
                for key in ['intent','motive','preserve','narrative_change','scope']:
                    if not isinstance(e.get(key),str) or not e[key].strip():issues.append('纠偏缺意图/动机/表达/叙事或范围：'+key)
                if e.get('motive_basis') not in {'user_stated','editor_inference','unknown'}:issues.append('动机未区分本人明说、编辑推测或未知')
                q=e.get('draft_quote','')
                if not isinstance(q,str) or len(q.strip())<4 or q not in body:issues.append('纠偏未落实到当前正文')
    elif feedback.get('mode')!='none_provided':issues.append('未核对本轮是否收到用户纠偏')
    return issues


def check(state,review):
    s=read(state);issues=[];current=loader().plan(s['task'])
    if s.get('current_ip')!=CURRENT_IP:issues.append('工作流归属与当前IP不同，不能跨人沿用')
    if {i['path'] for i in current['inventory']}!={i['path'] for i in s['inventory']}:issues.append('规则目录增删，须评估路由，不静默忽略新规则')
    if not {i['path'] for i in current['required']}.issubset({i['path'] for i in s['required']}):issues.append('本任务必读未加载完整')
    for i in s['required']:
        p=Path(i['path'])
        if not p.is_file() or sha(p)!=i['sha256']:issues.append('加载后来源变化或丢失：'+str(p))
    if not Path(review).is_file():return {'status':'blocked','issues':issues+['缺少审稿记录']}
    r=read(review)
    if r.get('task_id')!=s['task_id'] or r.get('task',s['task'])!=s['task']:issues.append('任务不一致')
    d=Path(r.get('draft',''))
    try:body,_=content(d) if d.is_file() else ('',{});body=draft_body(body)
    except ValueError as e:body='';issues.append(str(e))
    if not body or sha(d)!=r.get('draft_sha256'):issues.append('正文或交接文本已变化/丢失')
    if not r.get('reviewer','').strip():issues.append('未记录审稿者')
    if r.get('review_kind') not in {'self_review','independent_review'}:issues.append('评审类型不明')
    for i in s['required']:
        match=[a for a in r.get('rule_acknowledgements',[]) if a.get('path')==i['path']]
        if len(match)!=1:issues.append('来源理解记录缺失或重复：'+i['path']);continue
        a=match[0];q=a.get('rule_quote','').strip()
        if a.get('sha256')!=i['sha256'] or len(q)<4 or not a.get('application','').strip():issues.append('理解记录未完成：'+i['path']);continue
        try:source_body,_=content(i['path'])
        except ValueError as e:issues.append(str(e));continue
        if q not in source_body:issues.append('引句无法定位：'+i['path'])
    keys,mandatory=PROFILES[s['task']]
    if s['task'] in CONTENT_TASKS:
        mandatory=mandatory|{'sources'}
        try:
            issues.extend(grounding_issues(s,r,body))
            issues.extend(voice_issues(s,r,body))
        except (ValueError,OSError,KeyError,TypeError) as e:issues.append('取材记录损坏，停止交付：'+str(e))
    if r.get('source_evidence') and 'sources' in keys:mandatory=mandatory|{'sources'}
    for k in keys:
        match=[c for c in r.get('checks',[]) if c.get('id')==k]
        if len(match)!=1:issues.append('检查缺失或重复：'+k);continue
        c=match[0];status=c.get('status');q=c.get('draft_quote','').strip()
        if status not in {'pass','not_applicable'}:issues.append('检查未完成：'+k)
        if k in mandatory and status!='pass':issues.append('本任务核心项不能跳过：'+k)
        if not c.get('reason','').strip():issues.append('缺判断理由：'+k)
        if status=='pass' and (len(q)<4 or q not in body):issues.append('检查原句无法定位：'+k)
        if c.get('action','').strip() and not c.get('recheck','').strip():issues.append('修改未复判：'+k)
    for item in r.get('decisions',[]):
        if item.get('status')=='pending':issues.append('待负责人裁决：'+item.get('question',''))
    for item in r.get('source_evidence',[]):
        p=Path(item.get('path',''))
        if not p.is_file() or sha(p)!=item.get('sha256'):issues.append('证据变化或丢失：'+str(p))
    return {'status':'blocked' if issues else 'review_record_complete','issues':issues,'semantic_verification':'程序只核对记录与定位，不证明理由正确','review_kind':r.get('review_kind'),'user_acceptance':r.get('user_acceptance','not_recorded'),'effect_evidence':r.get('effect_evidence','not_tested'),'publication':'not_authorized_by_this_check'}
def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='cmd',required=True)
    for name in ['load','reload']:
        x=sub.add_parser(name);x.add_argument('--task',choices=loader().ROUTES,required=True);x.add_argument('--state',required=True);x.add_argument('--id',required=True);x.add_argument('--emit',action='store_true');x.add_argument('--extra',action='append',default=[])
    x=sub.add_parser('review-template');x.add_argument('--state',required=True);x.add_argument('--draft',required=True);x.add_argument('--review',required=True)
    x=sub.add_parser('check');x.add_argument('--state',required=True);x.add_argument('--review',required=True)
    a=p.parse_args()
    try:
        if a.cmd in {'load','reload'}:
            r=load(a.task,a.state,a.id,a.emit,a.extra,replace=a.cmd=='reload');result={'status':r['status'],'required_count':len(r['required'])}
        elif a.cmd=='review-template':template(a.state,a.draft,a.review);result={'status':'pending_review'}
        else:result=check(a.state,a.review)
        print(json.dumps(result,ensure_ascii=False,indent=2));return 1 if result['status']=='blocked' else 0
    except (ValueError,OSError,KeyError,TypeError) as e:
        print(json.dumps({'status':'blocked','error':str(e),'meaning':'未确认完成；已有当前状态在重载失败时保留'},ensure_ascii=False));return 2
if __name__=='__main__':raise SystemExit(main())
