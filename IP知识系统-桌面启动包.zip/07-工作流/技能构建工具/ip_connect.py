"""First-run connection helper. Inspect is read-only; configuration is not a connection proof."""
from __future__ import annotations
import argparse,asyncio,hashlib,importlib.metadata,json,os,re,subprocess,sys,time,uuid
from pathlib import Path

SERVER='ayou-ip-knowledge'
TOOLS=Path(__file__).resolve().parent
DEFAULT_ROOT=TOOLS.parents[1]
REQ='07-工作流/技能构建工具/ip_retrieval/requirements-integration.txt'

def sha(data):return hashlib.sha256(data).hexdigest()
def paths(root):
 root=Path(root).resolve();engine=root/'07-工作流/技能构建工具/ip_retrieval'
 return root,engine,engine/'.local'

def write_checked(path,data,expected):
 """Compare before committing, preserve preimage, never rewrite unchanged bytes."""
 path=Path(path);old=path.read_bytes() if path.exists() else None
 if old==data:return False
 if (sha(old) if old is not None else None)!=expected:raise RuntimeError('文件已被其他程序修改，停止覆盖：'+str(path))
 path.parent.mkdir(parents=True,exist_ok=True)
 if path.is_symlink() or (hasattr(path,'is_junction') and path.is_junction()):raise ValueError('拒绝写入重解析点')
 if old is not None:
  backup=path.parent/'.ip-system-backups';backup.mkdir(exist_ok=True)
  (backup/(path.name+'.'+sha(old)[:16]+'.bak')).write_bytes(old)
 tmp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp');tmp.write_bytes(data)
 # Second comparison covers edits while preparing backup/temp.
 now=path.read_bytes() if path.exists() else None
 if now!=old:tmp.unlink();raise RuntimeError('提交前文件变化，停止覆盖')
 os.replace(tmp,path);return True

def runtime_python(root):
 _,engine,_=paths(root);return engine/'.runtime/.venv'/('Scripts/python.exe' if os.name=='nt' else 'bin/python')

def dependency_check(python):
 script="import sys,importlib.metadata as m,json;print(json.dumps({'python':list(sys.version_info[:3]),'packages':{n:m.version(n) for n in ['mcp','tomlkit','numpy','jieba','haystack-ai','PyYAML','pypdf','python-docx','beautifulsoup4']}}))"
 try:
  cp=subprocess.run([str(python),'-B','-X','utf8','-c',script],capture_output=True,text=True,encoding='utf-8',timeout=30)
  if cp.returncode:return {'ready':False,'reason':'Python或检索依赖不完整'}
  d=json.loads(cp.stdout);d['ready']=d['python']>=[3,12,0]
  if not d['ready']:d['reason']='需要Python 3.12或以上'
  return d
 except (OSError,subprocess.TimeoutExpired,ValueError):return {'ready':False,'reason':'Python不可运行或检查超时'}

def config_path(home,client):
 if client not in {'codex','workbuddy'}:raise ValueError('需明确当前客户端为codex或workbuddy')
 return Path(home)/('.codex/config.toml' if client=='codex' else '.workbuddy/mcp.json')

def existing_python(root,home,client):
 """Reuse only an existing pointer to this exact vault, never a foreign server."""
 if client not in {'codex','workbuddy'}:return None
 p=config_path(home,client)
 if not p.exists():return None
 try:
  if client=='codex':
   import tomllib
   doc=tomllib.loads(p.read_text(encoding='utf-8-sig'))
  else:doc=json.loads(p.read_text(encoding='utf-8-sig'))
  e=doc.get('mcp_servers' if client=='codex' else 'mcpServers',{}).get(SERVER,{})
  engine=paths(root)[1]
  if e.get('args')==['-B','-X','utf8',str(engine/'mcp_server.py')]:return Path(e['command'])
 except (ValueError,KeyError,TypeError):pass
 return None

def inspect(root,home=None,client=None,python=None):
 root,engine,local=paths(root);home=Path(home or Path.home())
 needed=['启动IP知识系统.md','项目导航说明.md','协作共识与版本流转协议.md','01-系统交付物/SKILL.md','07-工作流/IP记忆成长与两端协作.md','07-工作流/检索接入.md','07-工作流/首次接入.md']
 missing=[x for x in needed if not (root/x).is_file()]
 candidates=[c for c in ['codex','workbuddy'] if config_path(home,c).exists()]
 if client=='mobile':return {'state':'mobile_lightweight','local_mcp_connected':False,'entry':'07-工作流/技能库/ayou-ip-mobile/手机启动包.md','writes_performed':False}
 if client not in {None,'codex','workbuddy'}:raise ValueError('未知客户端')
 py=Path(python) if python else existing_python(root,home,client) or runtime_python(root)
 deps=dependency_check(py)
 return {'state':'missing_sources' if missing else 'need_client' if not client else 'needs_runtime' if not deps['ready'] else 'ready_to_configure','root':str(root),'client':client,'installed_candidates':candidates,'candidate_is_current_client':False,'ask_if_unknown':'你现在使用的是Codex、WorkBuddy，还是手机AI应用？' if not client else None,'missing':missing,'runtime':deps,'python':str(py),'writes_performed':False,'connected':False,'next':'客户端明确后准备环境、合并配置，再做真实MCP试查；无环境时仍可按导航使用文件'}

def prepare(root):
 if sys.version_info<(3,12):raise RuntimeError('请由AI先定位Python 3.12或以上；不强迫用户自行学代码')
 root,engine,_=paths(root);py=runtime_python(root)
 if not py.exists():
  import venv
  venv.EnvBuilder(with_pip=True).create(py.parents[1])
 try:
  install_dependencies([str(py),'-m','pip','install','--disable-pip-version-check','-r',str(root/REQ)],600)
 except (subprocess.CalledProcessError,subprocess.TimeoutExpired,OSError,RuntimeError) as e:
  return {'ready':False,'stage':'runtime_not_ready','reason':type(e).__name__,'detail':str(e) if isinstance(e,RuntimeError) else '安装失败或下载超时，未完成运行环境验收','next':'下载或安装未完成；保留现有环境，不写MCP成功状态。检查网络后重试可复用缓存，或先按MD导航协作。','config_written':False}
 return dependency_check(py)

def install_dependencies(argv,timeout):
 proc=subprocess.Popen(argv)
 try:proc.wait(timeout=timeout)
 except subprocess.TimeoutExpired:
  if os.name=='nt':
   # venv Python on Windows has a launcher child; stop that tree before
   # declaring a timed-out download stopped.
   killed=subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True,timeout=20)
   if killed.returncode and proc.poll() is None:raise RuntimeError('安装超时，后台停止未确认，需核查PID '+str(proc.pid))
  else:proc.kill()
  proc.wait(timeout=20);raise
 if proc.returncode:raise subprocess.CalledProcessError(proc.returncode,argv)

def config_entry(root,python):
 root,engine,_=paths(root)
 revision=sha(b''.join((engine/n).read_bytes() for n in ['core.py','backend.py','mcp_server.py','local_settings.py']))[:16]
 return {'command':str(Path(python).resolve()),'args':['-B','-X','utf8',str(engine/'mcp_server.py')],'env':{'PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1','AYOU_KB_MANAGED_ROOT':str(root),'AYOU_KB_REVISION':revision}}

def read_config(path,client):
 if not path.exists():
  if client=='codex':
   import tomlkit
   return tomlkit.document()
  return {}
 if client=='codex':
  import tomlkit
  return tomlkit.parse(path.read_text(encoding='utf-8-sig'))
 return json.loads(path.read_text(encoding='utf-8-sig'))

def pointer(root):
 return ('---\nname: ayou-ip-coach\ndescription: IP知识系统相关的选题、骨架、写稿、实质改稿、审稿和复盘默认入口，无需重复@；按当前本人档案实际检索与回读，不负责自动发布。\n---\n\n# 共用IP知识系统入口\n\n'
  +'本机权威原件：`'+(root/'01-系统交付物/SKILL.md').as_posix()+'`。每次任务重新读取；方法只改主库。\n\n'
  +'用户说“启动IP知识系统”，先读主库根《启动IP知识系统.md》及 `07-工作流/首次接入.md`。沿用当前客户端信息，未知才问；先验连接后渐进认识本人。身份未知不套用阿柚资料。\n\n'
  +'检索统一读主库 `07-工作流/检索接入.md`；先kb_rules，再kb_search，引用前kb_read。没有实际调用不声称已连接、已检索。无法访问时报告缺口，已有任务可先按导航协作。安装目录仅保留本机指针。\n\n'
  +'实质内容任务沿 `01-系统交付物/手册/12-内容取材与交付门槛.md` 加载当前共识、具体材料及本人表达依据；按该发行版实际提供的检查器核对，不把安装或规则存在当已执行。无本地程序或只有手机包时明确能力范围。\n')

def configure(root,client,python=None,home=None,install_skill=False):
 root,engine,local=paths(root);home=Path(home or Path.home()).resolve();python=Path(python or runtime_python(root)).resolve()
 state=inspect(root,home,client,python)
 if state['state']!='ready_to_configure':raise RuntimeError('接入前置未满足：'+state['state'])
 path=config_path(home,client);old=path.read_bytes() if path.exists() else None;doc=read_config(path,client);key='mcp_servers' if client=='codex' else 'mcpServers'
 if key not in doc:doc[key]={}
 servers=doc[key];prior=servers.get(SERVER);entry=config_entry(root,python)
 if prior:
  marker=prior.get('env',{}).get('AYOU_KB_MANAGED_ROOT')
  ours=prior.get('args',[])==entry['args'] or marker==str(root)
  if not ours:raise RuntimeError('同名MCP指向其他库或未知程序，保留原配置，需负责人决定')
 # Preserve unknown existing per-server controls; update only managed command/args/env.
 if prior:
  entry={**prior,**entry}
  entry['env']={**dict(prior.get('env',{})),**entry['env']}
 skill_change=None
 if install_skill:
  dest=home/('.codex' if client=='codex' else '.workbuddy')/'skills/ayou-ip-coach/SKILL.md'
  previous=dest.read_bytes() if dest.exists() else None
  content=pointer(root)
  if previous is not None:
   text=previous.decode('utf-8-sig');forms=[str(root),root.as_posix()]
   if not any(x in text for x in forms):raise RuntimeError('同名Skill指向其他库，未替换，配置未写入')
   match=re.match(r'\A---\r?\n.*?\r?\n---\r?\n',text,re.S)
   if match:content=match[0].replace('\r\n','\n')+content.split('---',2)[2].lstrip('\n')
  skill_change=(dest,content.replace('\n','\r\n').encode('utf-8'),sha(previous) if previous is not None else None)
 if client=='codex':
  import tomlkit
  entry.setdefault('startup_timeout_sec',90);entry.setdefault('tool_timeout_sec',180)
  servers[SERVER]=entry;data=tomlkit.dumps(doc).encode('utf-8')
 else:
  if prior:entry={**prior,**entry}
  entry['type']='stdio';servers[SERVER]=entry;data=(json.dumps(doc,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
 changed=write_checked(path,data,sha(old) if old is not None else None)
 if skill_change:write_checked(*skill_change)
 result={'stage':'configured_not_yet_connected','client':client,'config':str(path),'config_sha256':sha(path.read_bytes()),'changed':changed,'root':str(root),'installed_skill':install_skill,'client_ui_verified':False,'requires_client_load':'若当前会话未发现工具，按软件提示重新加载配置或开新会话；不擅自关闭现有任务'}
 local.mkdir(parents=True,exist_ok=True);dest=local/('connection-'+client+'.json');old=dest.read_bytes() if dest.exists() else None
 write_checked(dest,(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf-8'),sha(old) if old is not None else None)
 return result

def register_profile(root,ip):
 root,engine,local=paths(root);sys.path.insert(0,str(engine))
 from local_settings import settings_path,load_settings
 if not re.fullmatch(r'[a-z0-9][a-z0-9_-]{0,47}',ip) or ip=='shared':raise ValueError('IP-ID需为1至48位小写字母数字下划线或短横线')
 s=load_settings(root);path=settings_path(root)
 if ip in s['profiles']:return {'state':'existing_profile_not_reset','ip':ip,'profile':s['profiles'][ip]}
 rel='02-私核-永不外传/IP档案/'+ip;dossier=root/rel/'ip-dossier.md'
 if dossier.exists():raise RuntimeError('已有未登记档案，先核对归属，不重置')
 # Existing AYOU private-root ownership may overlap: never silently nest another person's profile.
 for p in s['profiles'].values():
  for base in p.get('roots',[]):
   if rel==base or rel.startswith(base+'/') or base.startswith(rel+'/'):raise RuntimeError('新档案与已有个人映射重叠；此库非空白客户副本，需先分清归属')
 s['profiles'][ip]={'roots':[rel],'rules':[],'dossier':rel+'/ip-dossier.md'}
 body='---\nip_id: '+ip+'\nonboarding_status: in_progress\nonboarding_step: current_goal\n---\n\n# 当前IP档案\n\n仅记录当前本人明确提供与确认的信息。目标、经历、价值观、红线及反馈按需补充；缺口留空，不能套用维护者资料。\n'
 write_checked(dossier,body.encode('utf-8'),None)
 old=path.read_bytes() if path.exists() else None
 write_checked(path,(json.dumps(s,ensure_ascii=False,indent=2)+'\n').encode('utf-8'),sha(old) if old is not None else None)
 return {'state':'profile_created_read_back','ip':ip,'path':rel+'/ip-dossier.md','sha256':sha(dossier.read_bytes()),'status':'in_progress'}

async def probe(root,client,home=None):
 from mcp import ClientSession,StdioServerParameters
 from mcp.client.stdio import stdio_client
 root,engine,local=paths(root);path=config_path(home or Path.home(),client);doc=read_config(path,client);e=doc.get('mcp_servers' if client=='codex' else 'mcpServers',{}).get(SERVER)
 if not e:raise RuntimeError('尚未配置本库MCP')
 if e.get('enabled') is False:raise RuntimeError('此客户端配置已禁用本服务，请由用户决定启用')
 if e.get('args')!=config_entry(root,e['command'])['args']:raise RuntimeError('配置目标不符，不执行未知服务')
 env={**os.environ,**dict(e.get('env',{}))};params=StdioServerParameters(command=e['command'],args=list(e['args']),env=env)
 def value(r):
  if r.isError:raise RuntimeError('MCP工具返回失败')
  if r.structuredContent:return r.structuredContent
  return json.loads(next(x.text for x in r.content if x.type=='text'))
 async with stdio_client(params) as (reader,writer):
  async with ClientSession(reader,writer) as session:
   await session.initialize();listed=await session.list_tools();names={x.name for x in listed.tools}
   if not {'kb_status','kb_rules','kb_search','kb_read'}<=names:raise RuntimeError('工具列表不完整')
   status=value(await session.call_tool('kb_status',{}))
   revision=config_entry(root,e['command'])['env']['AYOU_KB_REVISION']
   if status.get('engine_revision')!=revision:raise RuntimeError('运行中的服务版本与当前代码不一致')
   rules=value(await session.call_tool('kb_rules',{'task':'general'}))
   sys.path.insert(0,str(engine))
   from local_settings import load_settings
   query_mode='rerank' if load_settings(root).get('relevance_gate') else 'bm25'
   found=value(await session.call_tool('kb_search',{'query':'IP知识系统','task':'general','mode':query_mode,'top_k':1}))
   if found.get('status')=='relevance_unavailable':
    # First search starts local vector recovery. Protocol and relevance remain distinct.
    for _ in range(60):
     await asyncio.sleep(2)
     ready=value(await session.call_tool('kb_status',{}))
     if ready.get('semantic_ready'):break
    found=value(await session.call_tool('kb_search',{'query':'IP知识系统','task':'general','mode':query_mode,'top_k':1}))
   if not found['hits']:raise RuntimeError('协议已连通，但试查无结果；不可报完整接入成功')
   read=value(await session.call_tool('kb_read',{'record_id':found['hits'][0]['id']}))
   if read['sha256']!=found['hits'][0]['sha256']:raise RuntimeError('来源回查不一致')
 result={'stage':'protocol_verified','client':client,'config_sha256':sha(path.read_bytes()),'engine_revision':config_entry(root,e['command'])['env']['AYOU_KB_REVISION'],'tools':sorted(names),'rule_receipt':rules['rule_receipt'],'generation':status['generation'],'read_path':read['path'],'read_sha256':read['sha256'],'mode':found['mode'],'query_receipt':found['receipt'],'service_pid':status.get('service_pid'),'client_ui_verified':False,'ai_automatic_use_verified':False,'new_physical_machine_verified':False,'verified_at':time.strftime('%Y-%m-%d %H:%M:%S')}
 dest=local/('probe-'+client+'.json');old=dest.read_bytes() if dest.exists() else None
 write_checked(dest,(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf-8'),sha(old) if old is not None else None)
 return result

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['inspect','prepare','configure','probe','profile']);p.add_argument('--vault',type=Path,default=DEFAULT_ROOT);p.add_argument('--client',choices=['codex','workbuddy','mobile']);p.add_argument('--python',type=Path);p.add_argument('--home',type=Path);p.add_argument('--install-skill',action='store_true');p.add_argument('--ip')
 a=p.parse_args()
 # The launcher may be a bundled Python with no MCP/tomlkit. Re-run mutation/probe
 # commands inside the validated target environment rather than modifying it.
 if a.command in {'configure','probe'}:
  target=Path(a.python or runtime_python(a.vault)).resolve()
  if a.command=='probe' and not a.python:
   cp=config_path(a.home or Path.home(),a.client)
   if cp.exists():
    if a.client=='codex':
     import tomllib
     doc=tomllib.loads(cp.read_text(encoding='utf-8-sig'))
    else:doc=json.loads(cp.read_text(encoding='utf-8-sig'))
    e=doc.get('mcp_servers' if a.client=='codex' else 'mcpServers',{}).get(SERVER,{})
    if e and e.get('args')==config_entry(a.vault,e['command'])['args']:target=Path(e['command']).resolve()
  if target!=Path(sys.executable).resolve():
   if not dependency_check(target)['ready']:raise RuntimeError('目标运行环境未就绪，先prepare或定位可用环境')
   if os.environ.get('AYOU_CONNECT_RELAY')=='1':raise RuntimeError('解释器接续异常，停止重复启动')
   result=subprocess.run([str(target),'-B','-X','utf8',str(Path(__file__).resolve()),*sys.argv[1:]],env={**os.environ,'AYOU_CONNECT_RELAY':'1'})
   raise SystemExit(result.returncode)
 if a.command=='inspect':r=inspect(a.vault,a.home,a.client,a.python)
 elif a.command=='prepare':r=prepare(a.vault)
 elif a.command=='configure':r=configure(a.vault,a.client,a.python,a.home,a.install_skill)
 elif a.command=='probe':r=asyncio.run(asyncio.wait_for(probe(a.vault,a.client,a.home),timeout=240))
 else:r=register_profile(a.vault,a.ip or '')
 print(json.dumps(r,ensure_ascii=False,indent=2))
 if a.command=='prepare' and not r.get('ready'):raise SystemExit(2)
if __name__=='__main__':main()
