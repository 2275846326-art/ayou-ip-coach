"""Confirmed-profile adapter for the shared content checker; no personal rule copy."""
from pathlib import Path
import argparse,importlib.util,json,sys

HERE=Path(__file__).resolve().parent
def configure(root,ip):
    root=Path(root).resolve();eng=root/'07-工作流/技能构建工具/ip_retrieval'
    sys.path.insert(0,str(eng))
    from local_settings import load_settings,relative_path
    settings=load_settings(root);profile=settings['profiles'].get(ip)
    if not profile:raise ValueError('先由本人确认独立IP-ID并登记档案，不能默认套维护者')
    spec=importlib.util.spec_from_file_location('shared_content_gate',HERE/'content_gate.py')
    w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w);w.CURRENT_IP=ip
    class Plan:
        ROUTES={k:[] for k in w.PROFILES}
        def plan(self,task):
            methods=['01-系统交付物/SKILL.md','01-系统交付物/手册/00-心法与判断纪律.md']
            methods+=['01-系统交付物/手册/'+({'topic':'02-选题手册.md','script':'03-写稿手册.md','wechat':'03-写稿手册.md','learning':'12-内容取材与交付门槛.md','cover':'08-封面制作标准.md','layout':'10-图文内容逻辑.md'}[task])]
            if task in w.CONTENT_TASKS:methods+=['01-系统交付物/手册/11-个人口吻与语感校准.md','01-系统交付物/手册/12-内容取材与交付门槛.md']
            methods+=profile.get('rules',[])+[profile['dossier']]
            paths=[relative_path(root,x) for x in dict.fromkeys(methods)]
            if any(not x.is_file() for x in paths):raise ValueError('方法或当前本人档案缺失')
            records=[{'path':str(x),'sha256':w.sha(x)} for x in paths]
            return {'required':records,'inventory':records}
    w.loader=lambda:Plan();w.receipt_root=lambda:eng/'.runtime/receipts'
    return w,profile

def main(argv=None):
    p=argparse.ArgumentParser(add_help=False);p.add_argument('--vault',type=Path,default=HERE.parents[1]);p.add_argument('--ip',required=True)
    args,rest=p.parse_known_args(argv);w,pf=configure(args.vault,args.ip)
    # Outputs stay in this person's workspace. Another person's files are never
    # read as --extra merely because an ID was supplied. This is local filtering,
    # not authentication against an untrusted user with filesystem access.
    for flag in ['--state','--review','--draft','--extra']:
        for n,x in enumerate(rest[:-1]):
            if x!=flag:continue
            path=Path(rest[n+1]).resolve();root=args.vault.resolve()
            if not path.is_relative_to(root):raise ValueError('请先把授权材料放入当前知识库')
            rel=path.relative_to(root).as_posix()
            owned=any(rel==r or rel.startswith(r+'/') for r in pf['roots'])
            if (rel.startswith('02-私核-永不外传/') and not owned) or (flag!='--extra' and not owned):raise ValueError('不读写其他IP的私人文件；产物放当前本人档案目录')
    sys.argv=[str(HERE/'content_gate.py'),*rest]
    return w.main()
if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,OSError,KeyError) as e:print(json.dumps({'status':'blocked','error':str(e)},ensure_ascii=False));raise SystemExit(2)
