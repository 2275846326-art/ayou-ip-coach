"""Versioned desktop bootstrap. No trust bypass, silent upgrade, or cloud deployment."""
from pathlib import Path,PurePosixPath
import argparse,asyncio,hashlib,json,os,re,subprocess,sys,time,uuid,zipfile
HERE=Path(__file__).resolve().parent
DEFAULT_ROOT=HERE.parents[1]
MANIFEST='.ip-release.json'
ENTRY_BEGIN='<!-- IP-SYSTEM:BEGIN -->'
ENTRY_END='<!-- IP-SYSTEM:END -->'
def digest(b):return hashlib.sha256(b).hexdigest()
def bounded(root,rel):
    root=Path(root).resolve();raw=PurePosixPath(rel)
    if raw.is_absolute() or '..' in raw.parts or '\\' in rel or ':' in rel:raise ValueError('发布路径非法')
    p=root/rel
    if not p.resolve().is_relative_to(root) or p.resolve()==root:raise ValueError('路径越界')
    for x in [p,*p.parents]:
        if x==root:break
        if x.is_symlink() or (hasattr(x,'is_junction') and x.is_junction()):raise ValueError('不写重解析点')
    return p
def release(root):
    m=json.loads((Path(root)/MANIFEST).read_text(encoding='utf-8'))
    if m.get('schema')!=1 or m.get('product')!='ayou-ip-desktop':raise ValueError('不是已识别的桌面发布包')
    if not isinstance(m.get('files'),dict) or not m['files']:raise ValueError('发布清单缺失')
    for rel,h in m['files'].items():
        bounded(root,rel)
        if rel.startswith(('02-私核','06-客户')) or any(x in PurePosixPath(rel).parts for x in ['.local','.runtime','.git','99-备份']):raise ValueError('发布清单不允许个人或运行资料')
        if not re.fullmatch('[0-9a-f]{64}',h):raise ValueError('文件指纹非法')
    return m
def verify_files(root,m):
    return [rel for rel,h in m['files'].items() if not bounded(root,rel).is_file() or digest(bounded(root,rel).read_bytes())!=h]
def connect_module(root):
    tools=Path(root)/'07-工作流/技能构建工具';sys.path.insert(0,str(tools))
    import ip_connect
    return ip_connect
def entry(root):
    root=Path(root).resolve()
    return (ENTRY_BEGIN+'\n仅对本知识库相关的IP任务：先实际读取 `'+(root/'启动IP知识系统.md').as_posix()+'`。\n'
    '每轮实质写作先读当前共识、本人档案及方法；实际检索、回读、核支持与条件，按内容工作流检查。未执行不得声称完成。\n'
    '首次先部署与验连接，再渐进建档；仅用本人的独立资料。简单确认与纯格式转换不重复整轮。安装不等于软件信任、自动调用或语义质量验证。\n'+ENTRY_END+'\n')
def install(root,client,home,python=None,prepare_runtime=True):
    root=Path(root).resolve();m=release(root);changed=verify_files(root,m)
    if changed:raise RuntimeError('发布文件已改变，先合并而非覆盖：'+str(changed))
    c=connect_module(root);home=Path(home).resolve()
    if client not in {'codex','workbuddy'}:
        return {'stage':'need_client','question':'你使用Codex、WorkBuddy，还是手机AI应用？','installed':False}
    py=Path(python) if python else c.existing_python(root,home,client) or c.runtime_python(root)
    if not c.dependency_check(py)['ready']:
        if not prepare_runtime:return {'stage':'runtime_missing','installed':False}
        ready=c.prepare(root)
        if not ready.get('ready'):return {'stage':'runtime_missing','runtime':ready,'installed':False}
        py=c.runtime_python(root)
    # All entry-point conflicts are checked before writing client configuration.
    agent=root/'AGENTS.md';old=agent.read_bytes() if agent.exists() else None
    text=old.decode('utf-8-sig') if old is not None else ''
    if text.count(ENTRY_BEGIN)!=text.count(ENTRY_END) or text.count(ENTRY_BEGIN)>1:raise RuntimeError('AGENTS托管区损坏，先人工合并')
    if ENTRY_BEGIN in text:text=re.sub(re.escape(ENTRY_BEGIN)+r'.*?'+re.escape(ENTRY_END)+'\n?',lambda _:entry(root),text,flags=re.S)
    else:text=text.rstrip()+'\n\n'+entry(root) if text else entry(root)
    state=c.configure(root,client,py,home,True)
    c.write_checked(agent,text.encode('utf-8'),digest(old) if old is not None else None)
    local=root/'07-工作流/技能构建工具/ip_retrieval/.local';dest=local/('deployment-'+client+'.json')
    result={'schema':1,'release_version':m['version'],'release_sha256':digest((root/MANIFEST).read_bytes()),'client':client,'stage':'configured_not_yet_connected','config':state,'project_entry_installed':True,'overriding_agents_present':(root/'AGENTS.override.md').exists(),'protocol_verified':False,'client_tools_verified':False,'automatic_use_verified':False,'semantic_retrieval_verified':False,'new_physical_machine_verified':False,'needs_reload_or_trust':'仅在软件实际要求时由本人允许或重载，不能绕过；不擅自关闭任务'}
    prior=dest.read_bytes() if dest.exists() else None
    if prior:
        previous=json.loads(prior)
        # A no-op install preserves proven protocol state only for identical code/config.
        if previous.get('release_sha256')==result['release_sha256'] and previous.get('config',{}).get('config_sha256')==state['config_sha256']:
            result.update({k:previous[k] for k in ['protocol_verified','probe'] if k in previous})
    c.write_checked(dest,(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode(),digest(prior) if prior is not None else None)
    return result
async def verify(root,client,home):
    root=Path(root).resolve();c=connect_module(root);m=release(root)
    if verify_files(root,m):raise RuntimeError('发布文件不一致，停止验收')
    probe=await asyncio.wait_for(c.probe(root,client,home),timeout=240)
    p=root/('07-工作流/技能构建工具/ip_retrieval/.local/deployment-'+client+'.json')
    old=p.read_bytes();d=json.loads(old)
    if d['release_sha256']!=digest((root/MANIFEST).read_bytes()):raise RuntimeError('请先按新版本重新部署')
    d.update(protocol_verified=True,probe=probe,stage='protocol_verified_client_pending')
    c.write_checked(p,(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode(),digest(old))
    return d
def doctor(root,client=None,home=None):
    root=Path(root).resolve();m=release(root);c=connect_module(root)
    mismatches=verify_files(root,m);out={'release_version':m['version'],'source_mismatches':mismatches,'environment':c.inspect(root,home,client),'capabilities':{'program_gate_included':(HERE/'content_gate.py').is_file(),'protocol_verified':False,'client_tools_verified':False,'automatic_use_verified':False,'semantic_retrieval_verified':False}}
    p=root/('07-工作流/技能构建工具/ip_retrieval/.local/deployment-'+str(client)+'.json')
    if p.exists():
        d=json.loads(p.read_text(encoding='utf-8'));fresh=d['release_sha256']==digest((root/MANIFEST).read_bytes()) and not mismatches
        out['deployment_fresh']=fresh
        if fresh:out['capabilities']['protocol_verified']=d.get('protocol_verified',False)
    return out
def attach_models(root,embedding,reranker):
    root=Path(root).resolve();c=connect_module(root)
    sys.path.insert(0,str(root/'07-工作流/技能构建工具/ip_retrieval'))
    from local_settings import load_settings,settings_path
    paths={k:Path(v).resolve() for k,v in [('embedding',embedding),('reranker',reranker)]}
    for kind,p in paths.items():
        if not p.is_dir() or not (p/'config.json').is_file() or not any(x.is_file() and x.suffix in {'.bin','.safetensors'} for x in p.iterdir()):raise ValueError('模型配置或权重不完整：'+kind)
        cfg=json.loads((p/'config.json').read_text(encoding='utf-8'))
        if cfg.get('auto_map'):raise ValueError('本入口不加载需要自定义远程代码的模型')
    # Registration is not a successful model load or relevance calibration.
    s=load_settings(root);p=settings_path(root);old=p.read_bytes() if p.exists() else None
    s['models']={**s.get('models',{}),**{k:str(v) for k,v in paths.items()}}
    c.write_checked(p,(json.dumps(s,ensure_ascii=False,indent=2)+'\n').encode(),digest(old) if old is not None else None)
    return {'stage':'models_registered_not_verified','semantic_retrieval_verified':False,'calibration_preserved':bool(s.get('relevance_gate')),'next':'在实际MCP会话重建向量并检索/回读；现有校准失配时保持阻断，不移除门槛'}
def upgrade(root,package,apply=False):
    root=Path(root).resolve();old=release(root);parent=(root/MANIFEST).read_bytes()
    with zipfile.ZipFile(package) as z:
        names=z.namelist()
        if len(names)!=len(set(names)) or sum(x.file_size for x in z.infolist())>15_000_000:raise ValueError('重复或过大的发布包')
        newraw=z.read(MANIFEST);new=json.loads(newraw)
        # Validate the new manifest through the same schema/paths without extracting.
        if new.get('product')!='ayou-ip-desktop' or new.get('schema')!=1:raise ValueError('升级产品不匹配')
        incoming={};conflicts=[]
        for rel,h in new['files'].items():
            p=bounded(root,rel)
            if rel.startswith(('02-私核','06-客户')) or any(k in PurePosixPath(rel).parts for k in ['.local','.runtime','.git','99-备份']):raise ValueError('升级不得覆盖个人或运行资料')
            b=z.read(rel)
            if digest(b)!=h:raise ValueError('升级包内容损坏')
            before=p.read_bytes() if p.exists() else None
            if before==b:continue
            if before is not None and (rel not in old['files'] or digest(before)!=old['files'][rel]):conflicts.append(rel)
            incoming[rel]=(b,before)
    result={'stage':'conflict' if conflicts else 'upgrade_preview','conflicts':conflicts,'writes':sorted(incoming),'old_version':old['version'],'new_version':new['version'],'removed_kept_for_review':sorted(set(old['files'])-set(new['files'])),'applied':False,'trust_verified':False}
    if not apply or conflicts:return result
    # A single cooperative writer lock, no override of unresolved locks.
    local=root/'07-工作流/技能构建工具/ip_retrieval/.local';local.mkdir(parents=True,exist_ok=True)
    lock=local/'upgrade.lock'
    fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    try:
        if (root/MANIFEST).read_bytes()!=parent:raise RuntimeError('父清单变化')
        for rel,(_,before) in incoming.items():
            p=bounded(root,rel)
            if (p.read_bytes() if p.exists() else None)!=before:raise RuntimeError('升级前并发变化')
        backup=local/('upgrade-'+uuid.uuid4().hex+'.zip')
        with zipfile.ZipFile(backup,'x',zipfile.ZIP_DEFLATED) as z:
            z.writestr(MANIFEST,parent)
            for rel,(_,before) in incoming.items():
                if before is not None:z.writestr(rel,before)
        c=connect_module(root)
        for rel,(b,before) in incoming.items():c.write_checked(bounded(root,rel),b,digest(before) if before is not None else None)
        c.write_checked(root/MANIFEST,newraw,digest(parent))
        result.update(applied=True,stage='upgrade_written_redeploy_required',backup=str(backup),after_manifest=digest(newraw),after_files={rel:digest(b) for rel,(b,_) in incoming.items()})
        backup.with_suffix('.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    finally:os.close(fd);lock.unlink()
    return result
def rollback(root,backup,apply=False):
    root=Path(root).resolve();local=root/'07-工作流/技能构建工具/ip_retrieval/.local';backup=Path(backup).resolve()
    if backup.parent!=local.resolve() or not re.fullmatch(r'upgrade-[a-f0-9]{32}\.zip',backup.name):raise ValueError('只能按本库升级回执恢复')
    rec=json.loads(backup.with_suffix('.json').read_text(encoding='utf-8'))
    if digest((root/MANIFEST).read_bytes())!=rec['after_manifest']:raise RuntimeError('升级后清单又变化，禁止回滚覆盖')
    for rel,h in rec['after_files'].items():
        p=bounded(root,rel)
        if not p.is_file() or digest(p.read_bytes())!=h:raise RuntimeError('升级后文件又有修改，先合并：'+rel)
    with zipfile.ZipFile(backup) as z:
        parent=z.read(MANIFEST);old=json.loads(parent);restores={rel:z.read(rel) for rel in rec['after_files'] if rel in old['files']}
    for rel,b in restores.items():
        if digest(b)!=old['files'][rel]:raise RuntimeError('备份指纹损坏')
    added=set(rec['after_files'])-set(old['files']);result={'stage':'rollback_preview','restore':sorted(restores),'quarantine_new_files':sorted(added),'applied':False}
    if not apply:return result
    fd=os.open(local/'upgrade.lock',os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    try:
        if digest((root/MANIFEST).read_bytes())!=rec['after_manifest']:raise RuntimeError('恢复前清单已变化')
        for rel,h in rec['after_files'].items():
            if digest(bounded(root,rel).read_bytes())!=h:raise RuntimeError('恢复前出现并发修改')
        for rel in added:
            dst=local/'rollback-new'/backup.stem/rel
            if not dst.resolve().is_relative_to(local.resolve()) or dst.exists():raise RuntimeError('恢复暂存目标异常')
        c=connect_module(root)
        for rel,b in restores.items():c.write_checked(bounded(root,rel),b,rec['after_files'][rel])
        for rel in added:
            src=bounded(root,rel);dst=local/'rollback-new'/backup.stem/rel
            if digest(src.read_bytes())!=rec['after_files'][rel]:raise RuntimeError('恢复移入备份前文件又变化')
            dst.parent.mkdir(parents=True,exist_ok=True);os.replace(src,dst)
        c.write_checked(root/MANIFEST,parent,rec['after_manifest']);result.update(applied=True,stage='rolled_back_redeploy_required')
    finally:os.close(fd);(local/'upgrade.lock').unlink()
    return result
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['inspect','start','install','verify','profile','models','upgrade','rollback']);p.add_argument('--vault',type=Path,default=DEFAULT_ROOT);p.add_argument('--client',choices=['codex','workbuddy','mobile']);p.add_argument('--home',type=Path,default=Path.home());p.add_argument('--python',type=Path);p.add_argument('--ip');p.add_argument('--package',type=Path);p.add_argument('--embedding',type=Path);p.add_argument('--reranker',type=Path);p.add_argument('--apply',action='store_true')
    a=p.parse_args()
    if a.client=='mobile':r={'stage':'mobile_lightweight','local_execution_available':False,'next':'提供手机启动包；不能据本地路径假装部署'}
    elif a.command=='inspect':r=doctor(a.vault,a.client,a.home)
    elif a.command=='upgrade':
        if not a.package:p.error('缺少升级包')
        r=upgrade(a.vault,a.package,a.apply)
    elif a.command=='rollback':
        if not a.package:p.error('提供本库升级备份路径')
        r=rollback(a.vault,a.package,a.apply)
    elif a.command in {'install','start'} and not a.client:r={'stage':'need_client','question':'你使用Codex、WorkBuddy，还是手机AI应用？','installed':False}
    elif a.command in {'install','start'}:
        if not a.apply:r={'stage':'preview_no_writes','inspection':doctor(a.vault,a.client,a.home)}
        else:
            c=connect_module(a.vault);target=a.python or c.existing_python(a.vault,a.home,a.client) or c.runtime_python(a.vault)
            if not c.dependency_check(target)['ready']:
                ready=c.prepare(a.vault)
                if not ready.get('ready'):raise RuntimeError('运行环境尚未就绪：'+str(ready))
                target=c.runtime_python(a.vault)
            if Path(target).resolve()!=Path(sys.executable).resolve():
                return subprocess.run([str(target),'-B','-X','utf8',str(Path(__file__).resolve()),*sys.argv[1:]]).returncode
            r=install(a.vault,a.client,a.home,target)
            if a.command=='start':r=asyncio.run(verify(a.vault,a.client,a.home))
    elif a.command=='verify':r=asyncio.run(verify(a.vault,a.client,a.home))
    elif a.command=='models':
        if not a.apply or not a.embedding or not a.reranker:p.error('提供合法本地模型路径并--apply')
        r=attach_models(a.vault,a.embedding,a.reranker)
    else:
        if not a.ip or not a.apply:p.error('本人确认IP-ID后才可带--ip和--apply建档')
        r=connect_module(a.vault).register_profile(a.vault,a.ip)
    print(json.dumps(r,ensure_ascii=False,indent=2));return 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,RuntimeError,OSError,KeyError,zipfile.BadZipFile) as e:print(json.dumps({'stage':'blocked','reason':str(e),'complete':False},ensure_ascii=False));raise SystemExit(2)
